import pandas as pd
from pathlib import Path

path = Path("03_Data/Aegis_Data_Classification_Worksheet_COMPLETED.xlsx")
df = pd.read_excel(path, sheet_name="classification")
required = ["sensitivity_level", "contains_personal_data", "who_should_access", "protection_needed", "your_reasoning"]
assert len(df) == 169, f"Expected 169 rows, found {len(df)}"
assert all(df[c].notna().all() for c in required), "Some classification fields are blank"
assert df["sensitivity_level"].isin(["Public", "Internal", "Confidential", "Restricted"]).all()
print("PASS: 169 columns classified; all required fields filled.")
print(df["sensitivity_level"].value_counts().reindex(["Public", "Internal", "Confidential", "Restricted"], fill_value=0))
