# Aegis Shield — Data Classification

## Purpose
Classify 169 fields across 11 workbook tables by sensitivity, personal-data status, access, and protection needs.

## Deliverables
- `03_Data/Aegis_Data_Classification_Worksheet_COMPLETED.xlsx` — completed field-level worksheet, summary counts/chart, table breakdown, and difficult decisions.
- `docs/difficult_decisions.md` — 20 difficult classification decisions and rationale.
- `docs/data_classification_method.md` — classification definitions and review caveats.
- `evidence/README.md` — add screenshots after uploading to GitHub.
- `scripts/validate_classification.py` — checks that 169 rows are classified and counts sum to 169.
- `hub/README.md` — project hub/overview.

## Sensitivity labels
- **Public:** approved for public release.
- **Internal:** routine non-public operational information.
- **Confidential:** personal, employee, client-contact, business transaction, or operational information needing restricted access.
- **Restricted:** highest-risk personal financial/payroll or similarly sensitive data requiring tightly scoped access.

## Important caveat
This is a reasoned first-pass classification based on the worksheet's field descriptions and examples. A real organization’s data owner, privacy/legal team, and security team should validate the labels against policy, applicable law, retention schedules, and business need. Example values are described as fictional in the source workbook.
