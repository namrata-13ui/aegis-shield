# Aegis Shield Project Hub

This hub tracks the Day 1 data-classification task. The completed worksheet classifies 169 columns across 11 tables and includes a sensitivity summary chart and 20 difficult decisions. See `../docs/` for method and rationale and `../03_Data/` for the worksheet.
