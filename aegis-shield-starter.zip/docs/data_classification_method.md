# Data Classification Method

## Labels
- **Public:** explicitly approved for public release. No column in this workbook was assumed public without explicit evidence.
- **Internal:** routine business operations data that should not be publicly released.
- **Confidential:** personal or employee-linked information, account activity, client contacts, commercial records, and information whose disclosure could cause harm.
- **Restricted:** high-impact individual payroll/compensation and detailed financial information requiring the narrowest access.

## Personal data
`Yes` means the field directly identifies a person or relates to an identifiable employee/account holder. `Indirect` means metadata may identify a person when joined with other records. `Potentially` means free text or a field can include personal details depending on actual values. Some fields are marked `No (business/financial...)` where they are commercial rather than personal, but may still be confidential.

## Access and protection
Recommendations use least privilege, role-based access, encryption, logging, masking/pseudonymization, approved exports, retention limits, reconciliation, and segregation of duties as appropriate to the field.

## Important limitations
- The worksheet uses fictional sample data, but classifications should be based on the sensitivity of the field if populated with real data.
- Cross-table joins can increase sensitivity. Employee IDs occur across multiple tables and can connect HR, payroll, leave, and account activity.
- `exit_reason` is post-outcome data and may create target leakage if used for predictive modeling.
- `career_gap_months` is flagged as connected to a planted pay-bias example; it should not be used as a compensation-model input without formal fairness review.
- The completed file is a first-pass recommendation, not a legal determination or substitute for the organization's approved classification policy.
