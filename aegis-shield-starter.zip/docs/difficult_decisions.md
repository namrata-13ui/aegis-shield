# 20 Difficult Classification Decisions

## 1. `employees.employee_id`

- **Classification:** Confidential
- **Personal data:** Yes (linkable identifier)
- **Who should access:** HR and authorized managers; pseudonymous ID for analytics
- **Reasoning:** Stable IDs link an individual's records across all 11 tables, so their exposure can reveal a much richer profile than a single field.

## 2. `employees.gender`

- **Classification:** Confidential
- **Personal data:** Yes
- **Who should access:** HR only for legitimate purposes; fairness team with controlled access
- **Reasoning:** Gender is a protected/contextual attribute; do not use it as a model input for pay or employment decisions. Use only governed fairness testing.

## 3. `employees.date_of_birth`

- **Classification:** Confidential
- **Personal data:** Yes
- **Who should access:** HR; payroll only if required
- **Reasoning:** DOB is a direct personal attribute and can increase identity-theft and profiling risk when combined with other data.

## 4. `employees.career_gap_months`

- **Classification:** Confidential
- **Personal data:** Yes
- **Who should access:** HR; approved fairness analytics only
- **Reasoning:** The field is linked to a planted pay-bias scenario; using it in compensation or predictive decisions could perpetuate unfair treatment.

## 5. `employees.exit_reason`

- **Classification:** Confidential
- **Personal data:** Yes
- **Who should access:** HR and relevant manager on a need-to-know basis
- **Reasoning:** Exit reasons may reveal grievances, health, family, or other private circumstances; it is also post-outcome information and can cause model leakage.

## 6. `users.username`

- **Classification:** Confidential
- **Personal data:** Yes (account identifier)
- **Who should access:** IT/Security administrators; HR only when needed
- **Reasoning:** A login name is an account identifier; even though the example uses a fictional domain, real datasets could enable account targeting.

## 7. `users.last_login_at`

- **Classification:** Confidential
- **Personal data:** Yes (account activity)
- **Who should access:** IT/Security; system owner
- **Reasoning:** Login timestamps can reveal usage patterns and assist attackers in timing account attacks.

## 8. `users.password_policy_note`

- **Classification:** Internal
- **Personal data:** No
- **Who should access:** IT/Security and system owners
- **Reasoning:** The row explicitly says no passwords or hashes are stored. Keep the reminder internal, but never put actual credentials or hashes in this workbook.

## 9. `salary_revisions.previous_annual_fixed`

- **Classification:** Restricted
- **Personal data:** Yes (compensation)
- **Who should access:** Compensation/HR and authorized Finance only
- **Reasoning:** Historical individual salary is highly sensitive and may expose compensation inequity or facilitate financial/social engineering.

## 10. `salary_revisions.new_annual_fixed`

- **Classification:** Restricted
- **Personal data:** Yes (compensation)
- **Who should access:** Compensation/HR and authorized Finance only
- **Reasoning:** Current salary after revision has direct financial and employment consequences and must be tightly limited.

## 11. `performance_reviews.performance_rating`

- **Classification:** Confidential
- **Personal data:** Yes (performance record)
- **Who should access:** Employee, authorized manager, HR
- **Reasoning:** Appraisal ratings affect career outcomes and must not be broadly shared or used by automated models without governance.

## 12. `leave_requests.reason`

- **Classification:** Confidential
- **Personal data:** Yes (potentially health/family-related)
- **Who should access:** HR and approving manager; sensitive details limited to HR
- **Reasoning:** Free text can reveal health, family, or other sensitive details. Collect only necessary information and redact broad reports.

## 13. `payroll_items.net_pay`

- **Classification:** Restricted
- **Personal data:** Yes (financial)
- **Who should access:** Payroll and authorized Finance; approved auditor
- **Reasoning:** Take-home pay combines earnings and deductions and is highly sensitive personal financial data.

## 14. `payroll_items.calculation_note`

- **Classification:** Confidential
- **Personal data:** Yes (employment/payroll-linked)
- **Who should access:** Payroll team; Finance auditors
- **Reasoning:** Explanatory notes may expose pay calculation details or anomalies; restrict and review free-text content.

## 15. `journal_entries.total_debit`

- **Classification:** Confidential
- **Personal data:** No (financial/control data)
- **Who should access:** Finance Controller and authorized auditors
- **Reasoning:** Ledger totals reveal internal financial activity and require integrity controls even when not personal data.

## 16. `clients.payment_behaviour`

- **Classification:** Confidential
- **Personal data:** No (commercially sensitive)
- **Who should access:** Finance/credit control and account owner
- **Reasoning:** Payment-risk labels can affect commercial decisions and expose confidential assessments about a client.

## 17. `clients.contact_email`

- **Classification:** Confidential
- **Personal data:** Yes (business contact)
- **Who should access:** Account management and Finance; authorized recipients
- **Reasoning:** Contact details are personal data when they identify a person and can be used for phishing or targeted fraud.

## 18. `invoices.balance_due`

- **Classification:** Confidential
- **Personal data:** No (commercial financial data)
- **Who should access:** Finance/Accounts and relevant account owner
- **Reasoning:** Outstanding balances reveal client credit exposure and commercial position.

## 19. `expenses.description`

- **Classification:** Confidential
- **Personal data:** Potentially; inspect free text
- **Who should access:** Finance/Accounts and authorized approvers
- **Reasoning:** Free-text expense descriptions may contain personal, confidential, or security details not obvious from the column name.

## 20. `employees.exit_reason + payroll history`

- **Classification:** Restricted for combined analysis
- **Personal data:** Yes
- **Who should access:** Only approved HR/Finance analytics; privacy review
- **Reasoning:** Joining sensitive HR outcomes to salary history increases inference risk and may create bias/leakage; use minimization, pseudonymization and governed access.

