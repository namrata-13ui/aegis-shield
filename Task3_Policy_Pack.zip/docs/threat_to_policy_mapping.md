# Task 3 — Threat-to-Policy Mapping

**Status:** Draft. Check the threat IDs against the actual top 10 threats in your Day 2 STRIDE register before submitting.

| Threat | Related policies |
|---|---|
| Account compromise | POL-01, POL-02 |
| Privilege misuse | POL-01 |
| Unauthorised data exposure | POL-03, POL-04 |
| Data interception | POL-04 |
| Missing security evidence | POL-05 |
| Delayed incident handling | POL-06 |
| Data loss or ransomware | POL-07 |
| Vulnerable code or exposed secrets | POL-08 |
| Vendor or cloud exposure | POL-09 |
| Phishing or unsafe user behaviour | POL-02, POL-10 |

Replace these example descriptions with the actual top 10 threat IDs and scenarios from Day 2. A written policy does not prove a control is implemented.
